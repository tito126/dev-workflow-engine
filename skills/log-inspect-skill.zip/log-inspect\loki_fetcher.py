#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Loki 日志拉取模块 - 从 Grafana/Loki 拉取 K8s 环境日志

支持功能:
- 通过 Grafana 代理访问 Loki
- 按时间范围查询
- 按 label 过滤 (app, namespace 等)
- 输出到文件供 preprocess.py 处理
"""

import argparse
import json
import sys
import urllib.parse
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional


def parse_time(time_str: str) -> datetime:
    """解析时间字符串"""
    formats = [
        '%Y-%m-%d %H:%M:%S',
        '%Y-%m-%d %H:%M',
        '%Y-%m-%d',
    ]
    for fmt in formats:
        try:
            return datetime.strptime(time_str, fmt)
        except ValueError:
            continue
    raise ValueError(f"无法解析时间: {time_str}")


def datetime_to_ns(dt: datetime) -> int:
    """转换为纳秒时间戳"""
    return int(dt.timestamp() * 1_000_000_000)


def query_loki(
    grafana_url: str,
    datasource_id: int,
    query: str,
    start: datetime,
    end: datetime,
    limit: int = 5000,
) -> list:
    """
    通过 Grafana 代理查询 Loki
    
    Args:
        grafana_url: Grafana 地址，如 http://127.0.0.1:16848
        datasource_id: Loki 数据源 ID
        query: LogQL 查询语句，如 {app="xxx"}
        start: 开始时间
        end: 结束时间
        limit: 返回行数限制
    
    Returns:
        日志行列表
    """
    # 构造 URL
    start_ns = datetime_to_ns(start)
    end_ns = datetime_to_ns(end)
    
    encoded_query = urllib.parse.quote(query)
    url = (
        f"{grafana_url}/api/datasources/proxy/{datasource_id}"
        f"/loki/api/v1/query_range"
        f"?query={encoded_query}"
        f"&start={start_ns}"
        f"&end={end_ns}"
        f"&limit={limit}"
        f"&direction=forward"
    )
    
    print(f"查询 Loki: {query}")
    print(f"时间范围: {start} ~ {end}")
    
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=60) as response:
            data = json.loads(response.read().decode('utf-8'))
    except Exception as e:
        print(f"查询失败: {e}")
        return []
    
    if data.get('status') != 'success':
        print(f"查询返回错误: {data}")
        return []
    
    # 提取日志行
    lines = []
    for stream in data.get('data', {}).get('result', []):
        for value in stream.get('values', []):
            # value[0] 是时间戳(纳秒), value[1] 是日志内容
            lines.append(value[1])
    
    print(f"获取到 {len(lines)} 条日志")
    return lines


def query_loki_adaptive(
    grafana_url: str,
    datasource_id: int,
    query: str,
    start: datetime,
    end: datetime,
    limit: int = 5000,
    min_chunk_minutes: float = 1.0,
    depth: int = 0,
) -> list:
    """
    自适应分片查询 Loki，确保获取所有日志
    
    工作原理：
    1. 先查询整个时间段
    2. 如果返回条数 < limit，说明没有截断，直接返回
    3. 如果返回条数 >= limit，说明可能有截断：
       - 如果时间段 > 最小分片，分成两半递归查询
       - 如果时间段 <= 最小分片，给出警告并返回
    
    Args:
        grafana_url: Grafana 地址
        datasource_id: Loki 数据源 ID
        query: LogQL 查询语句
        start: 开始时间
        end: 结束时间
        limit: 每次查询的行数限制
        min_chunk_minutes: 最小时间分片（分钟）
        depth: 递归深度（用于日志缩进）
    
    Returns:
        日志行列表
    """
    indent = "  " * depth
    time_span = (end - start).total_seconds() / 60  # 转换为分钟
    
    # 如果时间段 <= 最小分片，直接查询
    if time_span <= min_chunk_minutes:
        lines = query_loki(
            grafana_url=grafana_url,
            datasource_id=datasource_id,
            query=query,
            start=start,
            end=end,
            limit=limit,
        )
        
        # 检查是否可能有截断
        if len(lines) >= limit:
            print(f"{indent}[警告] {start.strftime('%H:%M')}~{end.strftime('%H:%M')} "
                  f"达到 {limit} 条限制，可能有数据截断")
        
        return lines
    
    # 查询整个时间段
    lines = query_loki(
        grafana_url=grafana_url,
        datasource_id=datasource_id,
        query=query,
        start=start,
        end=end,
        limit=limit,
    )
    
    # 如果未达到 limit，说明没有截断，直接返回
    if len(lines) < limit:
        return lines
    
    # 达到 limit，说明可能有截断，分成两半递归查询
    print(f"{indent}[分片] 检测到可能的数据截断，将 {start.strftime('%H:%M')}~{end.strftime('%H:%M')} "
          f"({time_span:.1f}分钟) 分成两半重新查询...")
    
    mid = start + (end - start) / 2
    
    lines_left = query_loki_adaptive(
        grafana_url=grafana_url,
        datasource_id=datasource_id,
        query=query,
        start=start,
        end=mid,
        limit=limit,
        min_chunk_minutes=min_chunk_minutes,
        depth=depth + 1,
    )
    
    lines_right = query_loki_adaptive(
        grafana_url=grafana_url,
        datasource_id=datasource_id,
        query=query,
        start=mid,
        end=end,
        limit=limit,
        min_chunk_minutes=min_chunk_minutes,
        depth=depth + 1,
    )
    
    return lines_left + lines_right


def query_loki_chunked(
    grafana_url: str,
    datasource_id: int,
    query: str,
    start: datetime,
    end: datetime,
    chunk_minutes: int = 30,
    limit_per_chunk: int = 5000,
) -> list:
    """
    分块查询 Loki（旧版本，保留用于兼容性）
    
    推荐使用 query_loki_adaptive 替代此函数
    
    Args:
        chunk_minutes: 每次查询的时间跨度（分钟）
        limit_per_chunk: 每次查询的行数限制
    """
    all_lines = []
    current_start = start
    
    while current_start < end:
        current_end = min(current_start + timedelta(minutes=chunk_minutes), end)
        
        lines = query_loki(
            grafana_url=grafana_url,
            datasource_id=datasource_id,
            query=query,
            start=current_start,
            end=current_end,
            limit=limit_per_chunk,
        )
        
        all_lines.extend(lines)
        current_start = current_end
    
    return all_lines


def build_query(
    app: Optional[str] = None,
    namespace: Optional[str] = None,
    pod: Optional[str] = None,
    level_filter: Optional[str] = None,
) -> str:
    """
    构建 LogQL 查询语句
    
    Args:
        app: 应用名
        namespace: K8s 命名空间
        pod: Pod 名称
        level_filter: 日志级别过滤，如 "ERROR|WARN"
    """
    labels = []
    if app:
        labels.append(f'app="{app}"')
    if namespace:
        labels.append(f'namespace="{namespace}"')
    if pod:
        labels.append(f'pod=~"{pod}.*"')
    
    if not labels:
        raise ValueError("至少需要指定一个 label (app/namespace/pod)")
    
    query = '{' + ', '.join(labels) + '}'
    
    if level_filter:
        query += f' |~ "{level_filter}"'
    
    return query


def main():
    parser = argparse.ArgumentParser(description='从 Loki 拉取日志')
    parser.add_argument('--grafana', '-g', required=True, help='Grafana 地址，如 http://127.0.0.1:16848')
    parser.add_argument('--datasource', '-d', type=int, default=1, help='Loki 数据源 ID，默认 1')
    parser.add_argument('--app', '-a', help='应用名 (app label)')
    parser.add_argument('--namespace', '-n', help='K8s 命名空间')
    parser.add_argument('--pod', '-p', help='Pod 名称前缀')
    parser.add_argument('--start', '-s', required=True, help='开始时间 (YYYY-MM-DD HH:MM)')
    parser.add_argument('--end', '-e', required=True, help='结束时间 (YYYY-MM-DD HH:MM)')
    parser.add_argument('--level', '-l', default='ERROR|WARN', help='日志级别过滤，默认 ERROR|WARN，设为空则不过滤')
    parser.add_argument('--output', '-o', default='loki_logs.log', help='输出文件路径')
    parser.add_argument('--chunk', type=int, default=30, help='[已弃用] 分块查询时间跨度(分钟)，默认 30（使用 --legacy 时生效）')
    parser.add_argument('--limit', type=int, default=5000, help='每次查询行数限制，默认 5000')
    parser.add_argument('--min-chunk', type=float, default=1.0, help='最小时间分片（分钟），默认 1.0')
    parser.add_argument('--legacy', action='store_true', help='使用旧版固定分片算法（不推荐）')
    
    args = parser.parse_args()
    
    # 解析时间
    try:
        start_time = parse_time(args.start)
        end_time = parse_time(args.end)
    except ValueError as e:
        print(f"时间格式错误: {e}")
        sys.exit(1)
    
    # 构建查询
    try:
        query = build_query(
            app=args.app,
            namespace=args.namespace,
            pod=args.pod,
            level_filter=args.level if args.level else None,
        )
    except ValueError as e:
        print(f"查询参数错误: {e}")
        sys.exit(1)
    
    print(f"LogQL: {query}")
    print(f"查询模式: {'旧版固定分片' if args.legacy else '自适应分片（推荐）'}")
    print()
    
    # 执行查询
    if args.legacy:
        # 使用旧版固定分片算法
        lines = query_loki_chunked(
            grafana_url=args.grafana.rstrip('/'),
            datasource_id=args.datasource,
            query=query,
            start=start_time,
            end=end_time,
            chunk_minutes=args.chunk,
            limit_per_chunk=args.limit,
        )
    else:
        # 使用新版自适应分片算法（推荐）
        lines = query_loki_adaptive(
            grafana_url=args.grafana.rstrip('/'),
            datasource_id=args.datasource,
            query=query,
            start=start_time,
            end=end_time,
            limit=args.limit,
            min_chunk_minutes=args.min_chunk,
        )
    
    if not lines:
        print("未获取到任何日志")
        sys.exit(0)
    
    # 写入文件
    output_path = Path(args.output)
    with open(output_path, 'w', encoding='utf-8') as f:
        for line in lines:
            f.write(line + '\n')
    
    print(f"\n完成! 共 {len(lines)} 条日志，已保存到 {output_path}")


if __name__ == '__main__':
    main()
