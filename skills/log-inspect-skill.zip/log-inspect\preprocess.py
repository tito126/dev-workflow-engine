#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
日志预处理脚本 - 从大日志文件中提取关键信息供 AI 分析

支持功能:
- 多文件/目录输入
- 自动解压 .gz 文件
- 时间范围过滤
- 提取 ERROR/WARN/FATAL 日志
- 提取慢接口 (响应时间 > 阈值)
- 错误分类统计
- 输出结构化 JSON 摘要
"""

import argparse
import gzip
import json
import os
import re
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# 日志行正则表达式
# 格式1 (普通服务器): [traceId,spanId,parentId] [,,] [IP:Port] [用户(userId)] 时间 [线程] 级别 类名 (文件:行) -- 内容
# 格式2 (K8s): [traceId,spanId,parentId] [IP:Port] [用户(userId)] 时间 [线程] 级别 类名 (文件:行) -- 内容
# 格式3 (工具组): [traceId,spanId,parentId] [,,] [IP:Port] [] [] 时间 [线程] 级别 类名 (文件:行) -- 内容
LOG_PATTERN = re.compile(
    r'\[([^]]*)\]\s*'  # traceId
    r'(?:\[([^]]*)\]\s*)?'  # [,,]
    r'\[([^]]*)\]\s*'  # IP:Port
    r'(?:\[([^]]*)\]\s*)?'  # field1
    r'(?:\[([^]]*)\]\s*)?'  # field2
    r'(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2},\d{3})\s*'  # timestamp
    r'\[([^\]]+)\]\s*'  # thread
    r'(\w+)\s+'  # level
    r'(\S+)\s*'  # class
    r'\([^)]*\)\s*'  # (file:line)
    r'--\s*'  # separator
    r'(.*)'  # content
)

# 慢接口正则: 业务处理耗时:XXX毫秒:/api/xxx 或 耗时:XXXms
SLOW_API_PATTERN = re.compile(r'[耗时:|耗时][:：]?\s*(\d+)\s*(?:毫秒|ms)[：:]?\s*(/\S+)?')

# 内部耗时日志正则: xxx耗时XXXms
INTERNAL_TIMING_PATTERN = re.compile(r'(.{0,50})耗时\s*(\d+)\s*(?:毫秒|ms)')

# 错误分类关键词
ERROR_CATEGORIES = {
    'NullPointerException': ['NullPointerException', 'null', 'NPE'],
    'SQLException': ['ORA-', 'SQLException', 'SQL Error', '数据库'],
    'TimeoutException': ['timeout', 'Timeout', '超时'],
    'AuthException': ['认证', '过期', 'token', 'Token', '权限'],
    'ValidationError': ['参数', '校验', 'validation', 'Validation'],
    'ConnectionError': ['Connection', '连接', 'refused', 'reset'],
    'OutOfMemory': ['OutOfMemory', 'OOM', '内存'],
}


def parse_timestamp(ts_str: str) -> Optional[datetime]:
    """解析日志时间戳"""
    try:
        return datetime.strptime(ts_str, '%Y-%m-%d %H:%M:%S,%f')
    except ValueError:
        return None


def categorize_error(content: str) -> str:
    """根据日志内容分类错误类型"""
    for category, keywords in ERROR_CATEGORIES.items():
        for keyword in keywords:
            if keyword in content:
                return category
    return 'Other'


def extract_user_info(user_field: str) -> Tuple[Optional[str], Optional[str]]:
    """从用户字段提取用户名和ID"""
    if not user_field:
        return None, None
    match = re.match(r'([^(]+)\((\d+)\)', user_field)
    if match:
        return match.group(1), match.group(2)
    return user_field, None


def parse_log_line(line: str) -> Optional[Dict]:
    """解析单行日志 - 支持多种格式"""
    match = LOG_PATTERN.match(line)
    if not match:
        return None
    
    groups = match.groups()
    trace_info = groups[0]
    
    # 现在有10个捕获组: trace, [,,], ip, field1, field2, time, thread, level, class, content
    # 找到时间戳的位置（最可靠的标识）
    timestamp_idx = None
    for i, g in enumerate(groups):
        if g and re.match(r'\d{4}-\d{2}-\d{2}', g):
            timestamp_idx = i
            break
    
    if timestamp_idx is None:
        return None
    
    # 时间戳之后的字段是固定的: thread, level, class, content
    timestamp = groups[timestamp_idx]
    thread = groups[timestamp_idx + 1] if timestamp_idx + 1 < len(groups) else ''
    level = groups[timestamp_idx + 2] if timestamp_idx + 2 < len(groups) else ''
    class_name = groups[timestamp_idx + 3] if timestamp_idx + 3 < len(groups) else ''
    content = groups[timestamp_idx + 4] if timestamp_idx + 4 < len(groups) else ''
    
    # 时间戳之前的字段: trace, [,,], ip, field1, field2
    # 找到 IP:Port (包含冒号和数字)
    ip_port = None
    user_field = None
    for i in range(1, timestamp_idx):
        if groups[i] and ':' in groups[i] and any(c.isdigit() for c in groups[i]):
            ip_port = groups[i]
        elif groups[i] and groups[i] != ',,' and groups[i].strip():
            # 非空且不是 [,,] 的字段可能是用户信息
            if '(' in groups[i] and ')' in groups[i]:
                user_field = groups[i]
    
    # 解析 traceId
    trace_parts = trace_info.split(',')
    trace_id = trace_parts[0] if trace_parts else None
    
    # 解析用户信息
    user_name, user_id = extract_user_info(user_field)
    
    # 解析时间戳
    ts = parse_timestamp(timestamp)
    
    return {
        'trace_id': trace_id,
        'ip_port': ip_port,
        'user_name': user_name,
        'user_id': user_id,
        'timestamp': ts,
        'timestamp_str': timestamp,
        'thread': thread,
        'level': level.upper() if level else '',
        'class_name': class_name,
        'content': content,
        'raw': line.strip()
    }



def is_in_time_range(ts: Optional[datetime], start: Optional[datetime], end: Optional[datetime]) -> bool:
    """检查时间是否在范围内"""
    if ts is None:
        return True  # 无法解析时间的行默认包含
    if start and ts < start:
        return False
    if end and ts > end:
        return False
    return True


def extract_slow_api(content: str) -> Optional[Dict]:
    """提取慢接口信息"""
    match = SLOW_API_PATTERN.search(content)
    if match:
        duration = int(match.group(1))
        api_path = match.group(2) if match.group(2) else 'unknown'
        return {'duration_ms': duration, 'api_path': api_path}
    return None


def extract_internal_timing(content: str) -> Optional[Dict]:
    """提取内部耗时信息"""
    match = INTERNAL_TIMING_PATTERN.search(content)
    if match:
        context = match.group(1).strip()
        duration = int(match.group(2))
        return {'context': context, 'duration_ms': duration}
    return None


def open_log_file(file_path: Path, encoding: str = 'utf-8'):
    """打开日志文件，支持 .gz 压缩"""
    if file_path.suffix == '.gz':
        return gzip.open(file_path, 'rt', encoding=encoding, errors='replace')
    else:
        return open(file_path, 'r', encoding=encoding, errors='replace')


def process_file(
    file_path: Path,
    start_time: Optional[datetime],
    end_time: Optional[datetime],
    slow_threshold_ms: int,
    encoding: str,
    stats: Dict
) -> None:
    """处理单个日志文件"""
    print(f"处理文件: {file_path}")
    
    line_count = 0
    error_lines = []
    warn_lines = []
    slow_apis = []
    internal_timings = []
    
    try:
        with open_log_file(file_path, encoding) as f:
            for line in f:
                line_count += 1
                
                # 解析日志行
                parsed = parse_log_line(line)
                if not parsed:
                    continue
                
                # 时间范围过滤
                if not is_in_time_range(parsed['timestamp'], start_time, end_time):
                    continue
                
                level = parsed['level']
                content = parsed['content']
                
                # 提取 ERROR/WARN
                if level in ('ERROR', 'FATAL'):
                    category = categorize_error(content)
                    stats['error_categories'][category] += 1
                    stats['error_count'] += 1
                    if len(error_lines) < 500:  # 限制样本数量
                        error_lines.append({
                            'timestamp': parsed['timestamp_str'],
                            'class': parsed['class_name'],
                            'user': parsed['user_name'],
                            'content': content[:500],  # 截断过长内容
                            'category': category,
                            'trace_id': parsed['trace_id']
                        })
                
                elif level == 'WARN':
                    stats['warn_count'] += 1
                    # 检查是否是慢接口日志
                    slow_api = extract_slow_api(content)
                    if slow_api and slow_api['duration_ms'] >= slow_threshold_ms:
                        slow_api['timestamp'] = parsed['timestamp_str']
                        slow_api['user'] = parsed['user_name']
                        slow_api['trace_id'] = parsed['trace_id']
                        slow_apis.append(slow_api)
                    elif len(warn_lines) < 200:
                        warn_lines.append({
                            'timestamp': parsed['timestamp_str'],
                            'class': parsed['class_name'],
                            'content': content[:300],
                        })
                
                # 提取内部耗时（INFO 级别也可能有）
                if '耗时' in content:
                    timing = extract_internal_timing(content)
                    if timing and timing['duration_ms'] >= slow_threshold_ms:
                        timing['timestamp'] = parsed['timestamp_str']
                        timing['trace_id'] = parsed['trace_id']
                        internal_timings.append(timing)
    
    except Exception as e:
        print(f"处理文件 {file_path} 出错: {e}")
        return
    
    stats['total_lines'] += line_count
    stats['error_samples'].extend(error_lines)
    stats['warn_samples'].extend(warn_lines)
    stats['slow_apis'].extend(slow_apis)
    stats['internal_timings'].extend(internal_timings)
    stats['files_processed'].append(str(file_path))


def aggregate_slow_apis(slow_apis: List[Dict]) -> List[Dict]:
    """聚合慢接口统计"""
    api_stats = defaultdict(lambda: {'count': 0, 'max_ms': 0, 'total_ms': 0, 'users': set(), 'samples': []})
    
    for api in slow_apis:
        path = api['api_path']
        duration = api['duration_ms']
        api_stats[path]['count'] += 1
        api_stats[path]['total_ms'] += duration
        api_stats[path]['max_ms'] = max(api_stats[path]['max_ms'], duration)
        if api.get('user'):
            api_stats[path]['users'].add(api['user'])
        if len(api_stats[path]['samples']) < 3:
            api_stats[path]['samples'].append(api)
    
    result = []
    for path, stat in sorted(api_stats.items(), key=lambda x: x[1]['max_ms'], reverse=True):
        result.append({
            'api_path': path,
            'count': stat['count'],
            'max_ms': stat['max_ms'],
            'avg_ms': stat['total_ms'] // stat['count'] if stat['count'] > 0 else 0,
            'users': list(stat['users'])[:5],  # 最多显示5个用户
            'samples': stat['samples']
        })
    
    return result[:50]  # 最多返回50个慢接口


def aggregate_errors(error_samples: List[Dict]) -> List[Dict]:
    """聚合错误统计，按内容相似度分组"""
    # 简单按类名+错误类型分组
    error_groups = defaultdict(lambda: {'count': 0, 'samples': [], 'users': set()})
    
    for err in error_samples:
        key = f"{err['category']}:{err['class']}"
        error_groups[key]['count'] += 1
        error_groups[key]['category'] = err['category']
        error_groups[key]['class'] = err['class']
        if err.get('user'):
            error_groups[key]['users'].add(err['user'])
        if len(error_groups[key]['samples']) < 3:
            error_groups[key]['samples'].append(err)
    
    result = []
    for key, group in sorted(error_groups.items(), key=lambda x: x[1]['count'], reverse=True):
        result.append({
            'category': group['category'],
            'class': group['class'],
            'count': group['count'],
            'users': list(group['users'])[:5],
            'samples': group['samples']
        })
    
    return result[:30]  # 最多返回30种错误


def find_log_files(input_path: str) -> List[Path]:
    """查找所有日志文件"""
    path = Path(input_path)
    files = []
    
    if path.is_file():
        files.append(path)
    elif path.is_dir():
        # 查找 .log, .log.*, .gz 文件
        for pattern in ['*.log', '*.log.*', '*.gz']:
            files.extend(path.glob(pattern))
    else:
        # 可能是 glob 模式
        files.extend(Path('.').glob(input_path))
    
    return sorted(files)


def main():
    parser = argparse.ArgumentParser(description='日志预处理脚本')
    parser.add_argument('input', nargs='+', help='输入文件或目录')
    parser.add_argument('-s', '--start', help='开始时间 (YYYY-MM-DD HH:MM)')
    parser.add_argument('-e', '--end', help='结束时间 (YYYY-MM-DD HH:MM)')
    parser.add_argument('-t', '--threshold', type=int, default=1000, help='慢接口阈值(ms)，默认1000')
    parser.add_argument('-o', '--output', default='digest.json', help='输出文件路径')
    parser.add_argument('--encoding', default='utf-8', help='日志文件编码')
    
    args = parser.parse_args()
    
    # 解析时间范围
    start_time = None
    end_time = None
    if args.start:
        try:
            start_time = datetime.strptime(args.start, '%Y-%m-%d %H:%M')
        except ValueError:
            print(f"无效的开始时间格式: {args.start}")
            sys.exit(1)
    if args.end:
        try:
            end_time = datetime.strptime(args.end, '%Y-%m-%d %H:%M')
        except ValueError:
            print(f"无效的结束时间格式: {args.end}")
            sys.exit(1)
    
    # 查找所有日志文件
    all_files = []
    for input_path in args.input:
        all_files.extend(find_log_files(input_path))
    
    if not all_files:
        print("未找到任何日志文件")
        sys.exit(1)
    
    print(f"找到 {len(all_files)} 个日志文件")
    
    # 初始化统计
    stats = {
        'total_lines': 0,
        'error_count': 0,
        'warn_count': 0,
        'error_categories': defaultdict(int),
        'error_samples': [],
        'warn_samples': [],
        'slow_apis': [],
        'internal_timings': [],
        'files_processed': [],
    }
    
    # 处理每个文件
    for file_path in all_files:
        process_file(file_path, start_time, end_time, args.threshold, args.encoding, stats)
    
    # 聚合结果
    digest = {
        'meta': {
            'generated_at': datetime.now().isoformat(),
            'files_processed': stats['files_processed'],
            'time_range': {
                'start': args.start,
                'end': args.end
            },
            'slow_threshold_ms': args.threshold,
        },
        'summary': {
            'total_lines': stats['total_lines'],
            'error_count': stats['error_count'],
            'warn_count': stats['warn_count'],
            'error_categories': dict(stats['error_categories']),
        },
        'errors': aggregate_errors(stats['error_samples']),
        'slow_apis': aggregate_slow_apis(stats['slow_apis']),
        'internal_timings': stats['internal_timings'][:50],  # 限制数量
        'warn_samples': stats['warn_samples'][:50],
    }
    
    # 输出结果
    output_path = Path(args.output)
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(digest, f, ensure_ascii=False, indent=2)
    
    print(f"\n处理完成!")
    print(f"- 总行数: {stats['total_lines']:,}")
    print(f"- ERROR: {stats['error_count']:,}")
    print(f"- WARN: {stats['warn_count']:,}")
    print(f"- 慢接口: {len(stats['slow_apis']):,}")
    print(f"- 输出: {output_path}")


if __name__ == '__main__':
    main()
