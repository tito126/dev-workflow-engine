#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成优化后的 HTML 日志分析报告（支持中文分类和优化建议）
"""
import json
import sys
import re
import os
from datetime import datetime
from collections import defaultdict

def parse_timestamp(ts_str):
    """解析时间戳"""
    try:
        return datetime.strptime(ts_str, '%Y-%m-%d %H:%M:%S,%f')
    except:
        return None

def analyze_trace_timeline(trace_lines):
    """分析trace的时间线，找出时间间隔过长的地方"""
    log_pattern = re.compile(
        r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3}).*?\[([^\]]+)\]\s+(\w+)\s+(\S+).*?--\s*(.*)'
    )
    
    timeline = []
    for line in trace_lines:
        match = log_pattern.search(line)
        if match:
            timestamp_str = match.group(1)
            thread = match.group(2)
            level = match.group(3)
            classname = match.group(4)
            content = match.group(5)
            
            timestamp = parse_timestamp(timestamp_str)
            if timestamp:
                timeline.append({
                    'timestamp': timestamp,
                    'timestamp_str': timestamp_str,
                    'thread': thread,
                    'level': level,
                    'class': classname,
                    'content': content
                })
    
    timeline.sort(key=lambda x: x['timestamp'])
    
    gaps = []
    for i in range(1, len(timeline)):
        prev = timeline[i-1]
        curr = timeline[i]
        gap_ms = int((curr['timestamp'] - prev['timestamp']).total_seconds() * 1000)
        
        if gap_ms > 100:
            gaps.append({
                'gap_ms': gap_ms,
                'prev': prev,
                'curr': curr,
                'prev_index': i-1,
                'curr_index': i
            })
    
    return timeline, gaps

def load_trace_logs(log_file, trace_id):
    """从原始日志文件中加载指定trace的所有日志，按时间正序排序"""
    if not log_file or not os.path.exists(log_file):
        return []
    
    trace_lines = []
    ts_pattern = re.compile(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}[,\.]\d+)')
    try:
        with open(log_file, 'r', encoding='utf-8') as f:
            for line in f:
                if trace_id in line:
                    m = ts_pattern.search(line)
                    ts = m.group(1) if m else ''
                    trace_lines.append((ts, line.strip()))
    except Exception as e:
        print(f"读取日志文件失败: {e}")
    
    # 按时间正序排序
    trace_lines.sort(key=lambda x: x[0])
    return [line for _, line in trace_lines]

def generate_error_category_cards(summary):
    """生成错误分类统计卡片"""
    html = ""
    for category, count in sorted(summary['error_categories'].items(), key=lambda x: x[1], reverse=True)[:3]:
        html += f"""
                    <div class="stat-card warning">
                        <div class="stat-number">{count}</div>
                        <div class="stat-label">{category}</div>
                    </div>
"""
    return html

def generate_error_category_table(summary):
    """生成错误分类详细表格"""
    html = """
                <table class="performance-table">
                    <thead>
                        <tr>
                            <th>错误类型</th>
                            <th>出现次数</th>
                            <th>占比</th>
                            <th>优化建议</th>
                        </tr>
                    </thead>
                    <tbody>
"""
    
    total_errors = summary['error_count']
    
    for category, count in sorted(summary['error_categories'].items(), key=lambda x: x[1], reverse=True):
        percentage = (count / total_errors * 100) if total_errors > 0 else 0
        
        # 根据分类名称匹配建议（从 ERROR_CATEGORIES）
        suggestion = "需要查看详细日志进行分析"
        if '空指针' in category:
            suggestion = "检查对象是否为空，添加空值校验"
        elif '认证' in category or '权限' in category:
            suggestion = "检查token是否过期，确认用户权限配置"
        elif 'SQL' in category:
            suggestion = "检查SQL语句语法，确认数据库连接正常"
        elif '超时' in category:
            suggestion = "检查网络连接，增加超时时间或优化接口性能"
        elif '连接' in category:
            suggestion = "检查网络连接，确认目标服务是否正常"
        elif '插件' in category:
            suggestion = "检查插件配置文件，确认插件是否正确安装"
        elif '参数' in category or '校验' in category:
            suggestion = "检查请求参数是否完整，确认参数格式正确"
        elif 'JSON' in category:
            suggestion = "检查JSON格式是否正确，确认数据结构"
        elif '内存' in category:
            suggestion = "增加JVM内存配置，检查是否有内存泄漏"
        elif '文件' in category:
            suggestion = "检查文件路径是否正确，确认文件是否存在"
        
        html += f"""
                        <tr>
                            <td><strong>{category}</strong></td>
                            <td>{count}</td>
                            <td>{percentage:.1f}%</td>
                            <td><span style="color: #1565c0;">💡 {suggestion}</span></td>
                        </tr>
"""
    
    html += """
                    </tbody>
                </table>
"""
    return html

def generate_log_quality_analysis(errors, summary):
    """生成日志质量分析"""
    # 从 summary 中获取统计信息
    total_samples = summary.get('error_samples_count', 0)
    no_api_entry_count = summary.get('no_api_entry_count', 0)
    null_content_count = summary.get('null_content_count', 0)
    
    # 如果 summary 中没有这些字段（旧版本 digest），则从 errors 中统计
    if total_samples == 0:
        for error_group in errors:
            samples = error_group.get('samples', [])
            total_samples += len(samples)
            
            for sample in samples:
                if not sample.get('api_entry'):
                    no_api_entry_count += 1
                
                content = sample.get('content', '').strip()
                if content == 'null':
                    null_content_count += 1
    
    # 统计影响级别
    impact_high = 0
    impact_medium = 0
    impact_low = 0
    
    for error_group in errors:
        category = error_group.get('category', '')
        if category in ['空指针异常', '数据库异常', '第三方调用异常', '标签配置问题']:
            impact_high += 1
        elif category in ['参数校验失败', 'JSON解析错误']:
            impact_medium += 1
        else:
            impact_low += 1
    
    # 计算比例
    no_api_ratio = (no_api_entry_count / total_samples * 100) if total_samples > 0 else 0
    null_ratio = (null_content_count / total_samples * 100) if total_samples > 0 else 0
    
    # 计算影响级别比例
    total_categories = len(errors)
    high_ratio = (impact_high / total_categories * 100) if total_categories > 0 else 0
    medium_ratio = (impact_medium / total_categories * 100) if total_categories > 0 else 0
    low_ratio = (impact_low / total_categories * 100) if total_categories > 0 else 0
    
    html = f"""
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                    <div style="background: #fff8e1; border-radius: 8px; padding: 16px;">
                        <div style="font-size: 1.8em; font-weight: bold; color: #f57c00;">{no_api_ratio:.1f}%</div>
                        <div style="color: #666; margin-top: 4px;">缺少 API 入口（{no_api_entry_count}/{total_samples} 条）</div>
                        <div style="color: #999; font-size: 0.85em; margin-top: 6px;">来自后台任务或异步调用，无 HTTP 请求上下文</div>
                    </div>
                    <div style="background: #fce4ec; border-radius: 8px; padding: 16px;">
                        <div style="font-size: 1.8em; font-weight: bold; color: #c62828;">{null_ratio:.1f}%</div>
                        <div style="color: #666; margin-top: 4px;">异常信息只有 null（{null_content_count}/{total_samples} 条）</div>
                        <div style="color: #999; font-size: 0.85em; margin-top: 6px;">日志记录不完整，建议研发改进异常捕获</div>
                    </div>
                </div>
                <div style="background: #f5f5f5; border-radius: 8px; padding: 16px;">
                    <div style="font-weight: bold; margin-bottom: 10px;">异常影响级别分布（共 {total_categories} 类）</div>
                    <div style="display: flex; height: 24px; border-radius: 4px; overflow: hidden; margin-bottom: 8px;">
                        <div style="width: {high_ratio}%; background: #ef5350;" title="影响主流程: {impact_high}类"></div>
                        <div style="width: {medium_ratio}%; background: #ffa726;" title="可能影响: {impact_medium}类"></div>
                        <div style="width: {low_ratio}%; background: #66bb6a;" title="不影响主流程: {impact_low}类"></div>
                    </div>
                    <div style="display: flex; gap: 20px; font-size: 0.85em; color: #666;">
                        <span>🔴 影响主流程 {impact_high} 类</span>
                        <span>🟡 可能影响 {impact_medium} 类</span>
                        <span>🟢 不影响主流程 {impact_low} 类</span>
                    </div>
                </div>
"""
    
    return html

def generate_error_details(errors, log_file=None):
    """生成错误详情"""
    html = ""
    
    for idx, error in enumerate(errors, 1):  # 显示所有错误
        # 确定严重程度
        severity = "high" if error['count'] >= 30 else "medium" if error['count'] >= 10 else "low"
        severity_text = "高严重程度" if severity == "high" else "中等严重程度" if severity == "medium" else "低严重程度"
        severity_emoji = "🔴" if severity == "high" else "🟡" if severity == "medium" else "🟢"
        
        html += f"""
                <div class="error-item" id="error-item-{idx}">
                    <div class="error-title">
                        <span>{severity_emoji} {idx}. {error['category']}</span>
                        <span class="severity-badge severity-{severity}">{severity_text}</span>
                    </div>
                    <p class="error-meta"><strong>出现次数:</strong> {error['count']} 次</p>
                    <p class="error-meta"><strong>位置:</strong> {error['class']}</p>
"""
        
        # API入口（从trace的最后一条日志提取）
        if error.get('samples'):
            sample = error['samples'][0]
            api_entry = sample.get('api_entry')
            
            if api_entry:
                html += f"""
                    <p class="error-meta"><strong>API入口:</strong> <code style="color: #1565c0;">{api_entry}</code></p>
"""
            
            # 调用方服务
            caller_service = sample.get('caller_service', error.get('caller_service', 'UNKNOWN'))
            if caller_service and caller_service != 'UNKNOWN':
                # 友好显示调用方
                caller_display = {
                    'SELF': '本服务',
                    'ASYNC': '异步任务',
                    'RPC': 'RPC调用',
                    'UNKNOWN': '未知'
                }.get(caller_service, caller_service.replace('winning-winex-ipt-', '').replace('-pbc', ''))
                
                html += f"""
                    <p class="error-meta"><strong>调用方:</strong> {caller_display}</p>
"""
            
            # 线程信息
            thread = sample.get('thread', '')
            if thread:
                html += f"""
                    <p class="error-meta"><strong>线程:</strong> {thread}</p>
"""
            
            # 影响级别
            impact_level = error.get('impact_level', sample.get('impact_level', ''))
            if impact_level:
                impact_text = {'high': '高影响', 'medium': '中影响', 'low': '低影响'}.get(impact_level, impact_level)
                impact_color = {'high': '#d32f2f', 'medium': '#f57c00', 'low': '#388e3c'}.get(impact_level, '#666')
                html += f"""
                    <p class="error-meta"><strong>影响级别:</strong> <span style="color: {impact_color}; font-weight: bold;">{impact_text}</span></p>
"""
        
        # 样例内容
        if error.get('samples'):
            sample = error['samples'][0]
            html += f"""
                    <div class="error-details">{sample.get('content', '')}</div>
"""
            
            # 提取接口源头信息（从日志内容中提取的其他API）
            api_sources = []
            api_pattern = re.compile(r'/api/[^\s,;)\]]+')
            
            for s in error['samples'][:10]:
                content = s.get('content', '')
                error_reason = s.get('error_reason', '')
                
                # 从content中提取
                for match in api_pattern.finditer(content):
                    api_path = match.group(0)
                    if api_path not in api_sources and len(api_path) > 5:
                        api_sources.append(api_path)
                
                # 从error_reason中提取
                for match in api_pattern.finditer(error_reason):
                    api_path = match.group(0)
                    if api_path not in api_sources and len(api_path) > 5:
                        api_sources.append(api_path)
            
            # 显示接口源头（如果有多个API）
            if api_sources:
                html += """
                    <div style="background: #e3f2fd; border-radius: 8px; padding: 15px; margin: 15px 0;">
                        <h5 style="color: #1565c0; margin-bottom: 10px;">🔗 接口源头</h5>
                        <ul style="list-style: none; margin: 0; padding: 0;">
"""
                for api in api_sources[:5]:
                    html += f"""
                            <li style="margin: 5px 0;"><code style="background: #fff; padding: 4px 10px; border-radius: 5px; font-size: 0.9em;">{api}</code></li>
"""
                html += """
                        </ul>
                    </div>
"""
            
            # TraceID 列表
            trace_ids = [s.get('trace_id', '') for s in error['samples'][:5] if s.get('trace_id')]
            if trace_ids:
                html += """
                    <div class="trace-list">
                        <h5>🔍 traceId 样例（可用于追踪完整调用链）</h5>
                        <ul>
"""
                for s in error['samples'][:5]:
                    if s.get('trace_id'):
                        html += f"""
                            <li><span class="trace-id">{s['trace_id']}</span> <span class="trace-time">{s.get('timestamp', '')[:16]}</span></li>
"""
                html += """
                        </ul>
                    </div>
"""
        
        # 完整链路日志（替代优化建议）
        rep_trace_id = ''
        if error.get('samples'):
            rep_trace_id = error['samples'][0].get('trace_id', '')
        
        if rep_trace_id and log_file:
            trace_logs = load_trace_logs(log_file, rep_trace_id)
            if trace_logs:
                def highlight(line, trace_id):
                    line = line.replace('<', '&lt;').replace('>', '&gt;')
                    # traceId - 黄色
                    if trace_id:
                        line = re.sub(
                            f'({re.escape(trace_id)})',
                            r'<span style="background:#ffe066;color:#000;font-weight:bold;">\1</span>',
                            line, flags=re.IGNORECASE
                        )
                    # error - 红色
                    line = re.sub(
                        r'(error)',
                        r'<span style="background:#e53935;color:#fff;font-weight:bold;">\1</span>',
                        line, flags=re.IGNORECASE
                    )
                    # .winning. 中间的 winning 标黄（前后必须是点）
                    line = re.sub(
                        r'(?<=\.)(winning)(?=\.)',
                        r'<span style="background:#ffe066;color:#000;font-weight:bold;">\1</span>',
                        line, flags=re.IGNORECASE
                    )
                    return line
                logs_html = '\n'.join(
                    f'<div class="trace-log-line">{highlight(line, rep_trace_id)}</div>'
                    for line in trace_logs
                )
                html += f"""
                    <div class="trace-chain-box">
                        <h4>🔗 完整链路日志（traceId: {rep_trace_id}，共 {len(trace_logs)} 条）</h4>
                        <div class="trace-chain-logs">{logs_html}</div>
                    </div>
                </div>
"""
            else:
                html += """
                </div>
"""
        else:
            html += """
                </div>
"""
    
    return html

def generate_html_report_v2(digest_file, output_file, hospital_name, service_name, time_range="", log_file=None):
    """生成优化后的 HTML 报告"""
    
    # 读取 digest
    with open(digest_file, 'r', encoding='utf-8') as f:
        digest = json.load(f)
    
    meta = digest['meta']
    summary = digest['summary']
    errors = digest['errors']
    slow_apis = digest.get('slow_apis', [])
    
    # 如果没有指定log_file，尝试从digest的meta中获取
    if not log_file and meta.get('files_processed'):
        log_file = meta['files_processed'][0]
    
    # 计算总慢接口调用次数
    total_slow_calls = sum(api['count'] for api in slow_apis)
    
    # 生成 HTML
    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>日志分析报告 - {hospital_name} {datetime.now().strftime('%Y-%m-%d')}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: 'Microsoft YaHei', 'Segoe UI', Tahoma, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }}
        .header {{
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #fff;
            padding: 40px;
            text-align: center;
        }}
        .header h1 {{ font-size: 2.5em; margin-bottom: 10px; }}
        .header .subtitle {{ font-size: 1.1em; opacity: 0.8; }}
        .content {{ padding: 40px; }}
        .section {{ margin-bottom: 40px; }}
        .section-title {{
            font-size: 1.8em;
            color: #1a1a2e;
            border-left: 5px solid #667eea;
            padding-left: 15px;
            margin-bottom: 25px;
        }}
        .info-card {{
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
        }}
        .info-table {{ width: 100%; border-collapse: collapse; }}
        .info-table td {{ padding: 12px 15px; border-bottom: 1px solid #e0e0e0; }}
        .info-table td:first-child {{ font-weight: bold; color: #1a1a2e; width: 180px; }}
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        .stat-card {{
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: #fff;
            border-radius: 12px;
            padding: 25px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }}
        .stat-card.danger {{ background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); }}
        .stat-card.warning {{ background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%); color: #333; }}
        .stat-number {{ font-size: 2.5em; font-weight: bold; margin-bottom: 10px; }}
        .stat-label {{ font-size: 1em; opacity: 0.9; }}
        .performance-table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }}
        .performance-table th, .performance-table td {{
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }}
        .performance-table th {{
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #fff;
        }}
        .performance-table tr:hover {{ background: #f5f5f5; }}
        .error-item {{
            background: #fff;
            border: 1px solid #e0e0e0;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        .error-title {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 1.3em;
            font-weight: bold;
            color: #1a1a2e;
            margin-bottom: 15px;
        }}
        .severity-badge {{
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.8em;
        }}
        .severity-high {{ background: #f8d7da; color: #721c24; }}
        .severity-medium {{ background: #fff3cd; color: #856404; }}
        .severity-low {{ background: #d4edda; color: #155724; }}
        .error-meta {{ margin: 8px 0; color: #666; }}
        .error-details {{
            background: #f8f9fa;
            border-left: 4px solid #667eea;
            padding: 15px;
            margin: 15px 0;
            font-family: 'Courier New', monospace;
            font-size: 0.9em;
            overflow-x: auto;
        }}
        .trace-list {{
            background: #e3f2fd;
            border-radius: 8px;
            padding: 15px;
            margin: 15px 0;
        }}
        .trace-list h5 {{ color: #1565c0; margin-bottom: 10px; }}
        .trace-list ul {{ list-style: none; }}
        .trace-list li {{ margin: 8px 0; }}
        .trace-id {{
            background: #fff;
            padding: 4px 10px;
            border-radius: 5px;
            font-family: 'Courier New', monospace;
            font-size: 0.9em;
            color: #1565c0;
        }}
        .trace-time {{ color: #666; font-size: 0.9em; margin-left: 10px; }}
        .suggestion-box {{
            background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
            border-radius: 12px;
            padding: 20px;
            margin-top: 15px;
        }}
        .suggestion-box h4 {{ color: #1565c0; margin-bottom: 10px; }}
        .trace-chain-box {{
            background: #1e1e1e;
            border-left: 4px solid #4caf50;
            padding: 15px;
            margin-top: 15px;
            border-radius: 0 4px 4px 0;
        }}
        .trace-chain-box h4 {{ color: #4caf50; margin-bottom: 10px; font-size: 0.9em; }}
        .trace-chain-logs {{
            max-height: 400px;
            overflow-y: auto;
            font-family: 'Courier New', monospace;
            font-size: 0.78em;
        }}
        .trace-log-line {{
            color: #d4d4d4;
            padding: 2px 0;
            border-bottom: 1px solid #333;
            white-space: pre-wrap;
            word-break: break-all;
        }}
        .footer {{
            background: #f8f9fa;
            padding: 20px;
            text-align: center;
            color: #666;
            border-top: 1px solid #e0e0e0;
        }}

        /* 导航栏样式 */
        .nav-sidebar {{
            position: fixed;
            left: 20px;
            top: 100px;
            width: 180px;
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            padding: 16px;
            max-height: calc(100vh - 140px);
            overflow-y: auto;
            z-index: 1000;
        }}
        .nav-sidebar h3 {{
            font-size: 1em;
            color: #1a1a2e;
            margin-bottom: 12px;
            padding-bottom: 8px;
            border-bottom: 2px solid #667eea;
        }}
        .nav-sidebar ul {{
            list-style: none;
        }}
        .nav-sidebar li {{
            margin-bottom: 6px;
        }}
        .nav-sidebar a {{
            color: #555;
            text-decoration: none;
            font-size: 0.88em;
            display: block;
            padding: 6px 10px;
            border-radius: 6px;
            transition: all 0.2s;
        }}
        .nav-sidebar a:hover {{
            background: #f0f0f0;
            color: #667eea;
            padding-left: 14px;
        }}
        .nav-sub {{
            list-style: none;
            margin: 4px 0 4px 8px;
            padding: 0;
            border-left: 2px solid #e0e0e0;
            display: none;
        }}
        .nav-sub.open {{ display: block; }}
        .nav-sub-link {{
            font-size: 0.8em !important;
            color: #888 !important;
            padding: 3px 8px !important;
        }}
        .nav-sub-link:hover {{
            color: #667eea !important;
            background: #f5f5f5 !important;
        }}
        .nav-toggle {{ cursor: pointer; user-select: none; }}
        @media (max-width: 1400px) {{
            .nav-sidebar {{ display: none; }}
        }}
    </style>
</head>
<body>

    <!-- 左侧导航栏 -->
    <div class="nav-sidebar">
        <h3>📑 目录</h3>
        <ul>
            <li><a href="#basic-info">基本信息</a></li>
            <li><a href="#log-quality">日志质量分析</a></li>
            <li><a href="#error-stats">异常统计概览</a></li>
            <li>
                <a href="#error-details" class="nav-toggle" onclick="toggleSub('sub-errors',this);return false;">▶ 详细异常分析</a>
                <ul class="nav-sub" id="sub-errors">
{chr(10).join(f'                    <li><a href="#error-item-{i}" class="nav-sub-link">{i}. {e["category"][:20]}{"…" if len(e["category"])>20 else ""}</a></li>' for i, e in enumerate(errors, 1))}
                </ul>
            </li>
            <li><a href="#log-feedback">日志反哺建议</a></li>
            <li>
                <a href="#slow-apis" class="nav-toggle" onclick="toggleSub('sub-slow',this);return false;">▶ 慢接口 Trace 详情</a>
                <ul class="nav-sub" id="sub-slow">
{chr(10).join(f'                    <li><a href="#slow-item-{i}" class="nav-sub-link">{i}. {a["api_path"].split("/")[-1][:25]}{"…" if len(a["api_path"].split("/")[-1])>25 else ""}</a></li>' for i, a in enumerate(slow_apis[:10], 1))}
                </ul>
            </li>
        </ul>
    </div>

    <script>
    function toggleSub(id, el) {{
        var sub = document.getElementById(id);
        if (sub.classList.contains('open')) {{
            sub.classList.remove('open');
            el.textContent = el.textContent.replace('▼','▶');
        }} else {{
            sub.classList.add('open');
            el.textContent = el.textContent.replace('▶','▼');
        }}
    }}
    </script>

    <div class="container">
        <div class="header">
            <h1>📊 日志分析报告</h1>
            <p class="subtitle">{hospital_name} | {time_range if time_range else datetime.now().strftime('%Y-%m-%d')}</p>
        </div>
        
        <div class="content">
            <!-- 基本信息 -->
            <div class="section" id="basic-info">
                <h2 class="section-title">基本信息</h2>
                <div class="info-card">
                    <table class="info-table">
                        <tr><td>医院名称</td><td>{hospital_name}</td></tr>
                        <tr><td>服务名称</td><td>{service_name}</td></tr>
"""
    
    # 显示拉取时间范围和拉取耗时
    fetch_start = meta.get('fetch_range', {}).get('start')
    fetch_end = meta.get('fetch_range', {}).get('end')
    fetch_duration = meta.get('fetch_range', {}).get('duration_s')
    
    if fetch_start or fetch_end:
        fetch_range_display = f"{fetch_start if fetch_start else 'N/A'} ~ {fetch_end if fetch_end else 'N/A'}"
        html += f"""
                        <tr><td>拉取时间范围</td><td>{fetch_range_display}</td></tr>
"""
        if fetch_duration is not None:
            html += f"""
                        <tr><td>拉取耗时</td><td>{fetch_duration} 秒</td></tr>
"""
    
    # 格式化生成时间
    generated_at = meta.get('generated_at', '')
    if 'T' in generated_at:
        # ISO格式，转换为更友好的格式
        try:
            dt = datetime.fromisoformat(generated_at)
            generated_at_display = dt.strftime('%Y-%m-%d %H:%M:%S')
        except:
            generated_at_display = generated_at.split('.')[0].replace('T', ' ')
    else:
        generated_at_display = generated_at
    
    html += f"""
                        <tr><td>分析日志量</td><td>{summary['total_lines']:,} 条</td></tr>
                        <tr><td>慢接口阈值</td><td>{meta['slow_threshold_ms']}ms</td></tr>
                        <tr><td>生成时间</td><td>{generated_at_display}</td></tr>
                    </table>
                </div>
            </div>

            <!-- 日志质量分析 -->
            <div class="section" id="log-quality">
                <h2 class="section-title">📊 日志质量分析</h2>
{generate_log_quality_analysis(errors, summary)}
            </div>

            <!-- 异常统计概览 -->
            <div class="section" id="error-stats">
                <h2 class="section-title">异常统计概览</h2>
                <div class="stats-grid">
{generate_error_category_cards(summary)}
                    <div class="stat-card danger">
                        <div class="stat-number">{len(slow_apis)}</div>
                        <div class="stat-label">慢接口类型</div>
                    </div>
                </div>
                
                <!-- 错误分类详细表格 -->
                <h3 style="margin-top: 30px; margin-bottom: 15px; color: #1a1a2e;">错误分类详情</h3>
{generate_error_category_table(summary)}
            </div>

            <!-- 详细异常分析 -->
            <div class="section" id="error-details">
                <h2 class="section-title">详细异常分析</h2>
{generate_error_details(errors, log_file)}
            </div>

            <!-- 日志反哺模块 -->
            <div class="section" id="log-feedback">
                <h2 class="section-title">📝 日志反哺建议</h2>
                <p style="margin-bottom: 20px; color: #666;">以下异常的日志内容不够明确，建议开发团队改进日志输出</p>
"""
    
    # 分析不明确的日志（按问题类型分组）
    issues_map = {
        'null_content': {'name': '日志内容只有"null"', 'categories': []},
        'no_trace': {'name': '缺少traceId', 'categories': []},
        'short_content': {'name': '日志内容过短', 'categories': []}
    }
    
    for error_group in errors:
        category = error_group['category']
        
        # 跳过认证/权限问题
        if category == '认证/权限问题':
            continue
            
        samples = error_group['samples']
        
        # 分析各类问题
        null_samples = []
        no_trace_samples = []
        short_samples = []
        
        for s in samples[:10]:
            content = s.get('content', '').strip()
            trace_id = s.get('trace_id')
            
            if content == 'null':
                null_samples.append(s)
            elif not trace_id:
                no_trace_samples.append(s)
            elif len(content) < 20 and not re.search(r'[A-Z]{2}\d{4,}', content):
                short_samples.append(s)
        
        if null_samples:
            issues_map['null_content']['categories'].append({
                'category': category,
                'count': len(null_samples),
                'samples': null_samples[:3]
            })
        
        if no_trace_samples:
            issues_map['no_trace']['categories'].append({
                'category': category,
                'count': len(no_trace_samples),
                'samples': no_trace_samples[:3]
            })
        
        if short_samples:
            issues_map['short_content']['categories'].append({
                'category': category,
                'count': len(short_samples),
                'samples': short_samples[:3]
            })
    
    # 生成反馈内容
    has_issues = any(issue['categories'] for issue in issues_map.values())
    
    if has_issues:
        for issue_key, issue_data in issues_map.items():
            if not issue_data['categories']:
                continue
            
            total_count = sum(cat['count'] for cat in issue_data['categories'])
            affected_categories = ', '.join([f"{cat['category']}({cat['count']}个)" for cat in issue_data['categories'][:5]])
            
            html += f"""
                <div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 20px; margin: 20px 0; border-radius: 8px;">
                    <h4 style="color: #856404; margin-bottom: 10px;">⚠️ 问题：{issue_data['name']}</h4>
                    <p style="color: #666; margin-bottom: 15px;">
                        <strong>受影响分类：</strong>{affected_categories}<br>
                        <strong>总计：</strong>{total_count} 个样本
                    </p>
                    <div style="background: white; border-radius: 8px; padding: 15px; margin-top: 10px;">
                        <h5 style="color: #1a1a2e; margin-bottom: 10px;">样本示例：</h5>
                        <table class="performance-table">
                            <thead>
                                <tr>
                                    <th>分类</th>
                                    <th>类名</th>
                                    <th>内容</th>
                                    <th>traceId</th>
                                </tr>
                            </thead>
                            <tbody>
"""
            
            # 显示样本
            for cat in issue_data['categories'][:3]:
                for sample in cat['samples'][:2]:
                    content_display = sample.get('content', '')[:60].replace('<', '&lt;').replace('>', '&gt;')
                    trace_display = sample.get('trace_id', '<span style="color: #e74c3c;">无</span>')
                    if trace_display and trace_display != '<span style="color: #e74c3c;">无</span>':
                        trace_display = f'<code>{trace_display[:20]}...</code>'
                    
                    html += f"""
                                <tr>
                                    <td>{cat['category']}</td>
                                    <td><code>{sample.get('class', '')}</code></td>
                                    <td>{content_display}</td>
                                    <td>{trace_display}</td>
                                </tr>
"""
            
            html += """
                            </tbody>
                        </table>
                    </div>
"""
            
            # 改进建议
            if issue_key == 'null_content':
                suggestion = "在代码中添加详细的错误信息，避免只输出\"null\"。建议格式：log.error(\"操作失败，参数={}, 原因={}\", param, e.getMessage())"
            elif issue_key == 'no_trace':
                suggestion = "在日志输出时添加traceId，便于追踪完整调用链。建议在过滤器或拦截器中统一生成traceId"
            else:
                suggestion = "增加日志的上下文信息，包括关键参数、操作对象、错误原因等"
            
            html += f"""
                    <p style="margin-top: 15px; padding: 10px; background: #e8f5e9; border-radius: 5px; color: #2e7d32;">
                        <strong>💡 改进建议：</strong>{suggestion}
                    </p>
                </div>
"""
    else:
        html += """
                <div style="background: #d4edda; border-left: 4px solid #28a745; padding: 15px; margin: 20px 0; border-radius: 8px;">
                    <p style="color: #155724; margin: 0;">✅ 所有异常日志内容都较为明确，无需反哺</p>
                </div>
"""
    
    html += """
            </div>

            <!-- 慢接口分析 -->
            <div class="section">
                <h2 class="section-title">慢接口分析</h2>
                <p style="margin-bottom: 20px; color: #666;">共发现 """ + str(len(slow_apis)) + """ 种慢接口，累计 """ + str(total_slow_calls) + """ 次慢调用</p>
                <table class="performance-table">
                    <thead>
                        <tr>
                            <th>接口路径</th>
                            <th>调用次数</th>
                            <th>最大耗时</th>
                            <th>平均耗时</th>
                        </tr>
                    </thead>
                    <tbody>
"""
    
    for api in slow_apis[:20]:
        html += f"""
                        <tr>
                            <td><code>{api['api_path']}</code></td>
                            <td>{api['count']}</td>
                            <td><span class="time-badge time-critical">{api['max_ms']}ms</span></td>
                            <td><span class="time-badge time-warning">{api['avg_ms']}ms</span></td>
                        </tr>
"""
    
    html += """
                    </tbody>
                </table>
            </div>

            <!-- 慢接口 Trace 详情 -->
            <div class="section" id="slow-apis">
                <h2 class="section-title">慢接口 Trace 详情</h2>
"""

    for idx, api in enumerate(slow_apis[:10], 1):
        html += f"""
                <div class="error-item" id="slow-item-{idx}">
                    <div class="error-title">
                        <span>🐌 {idx}. <code>{api['api_path']}</code></span>
                        <span class="severity-badge severity-medium">Top 慢接口</span>
                    </div>
                    <p class="error-meta"><strong>调用次数:</strong> {api['count']} 次</p>
                    <p class="error-meta"><strong>最大耗时:</strong> {api['max_ms']}ms</p>
                    <p class="error-meta"><strong>平均耗时:</strong> {api['avg_ms']}ms</p>
"""

        top_traces = api.get('top_traces', [])
        if top_traces:
            html += """
                    <div class="trace-list">
                        <h5>🔍 代表 trace</h5>
                        <ul>
"""
            for trace in top_traces[:5]:
                html += f"""
                            <li>
                                <span class="trace-id">{trace.get('trace_id', 'unknown')}</span>
                                <span class="trace-time">{trace.get('timestamp', '')[:19]} / {trace.get('duration_ms', 0)}ms</span>
                            </li>
"""
            html += """
                        </ul>
                    </div>
"""
        
        # 时间间隔分析（从 log_file 加载第一个 top_trace）
        if log_file and top_traces:
            trace_id = top_traces[0].get('trace_id')
            if trace_id:
                trace_lines = load_trace_logs(log_file, trace_id)
                if trace_lines:
                    timeline, gaps = analyze_trace_timeline(trace_lines)
                    
                    if gaps:
                        gaps.sort(key=lambda x: -x['gap_ms'])
                        # 只显示 >100ms 的间隔
                        significant_gaps = [g for g in gaps if g['gap_ms'] > 100]
                        
                        if significant_gaps:
                            html += f"""
                    <div class="suggestion-box" style="background: #fff3cd; border: 2px solid #ffc107;">
                        <h4>⏱️ 时间间隔分析 (发现 {len(significant_gaps)} 个间隔 > 100ms)</h4>
"""
                            for j, gap in enumerate(significant_gaps[:5], 1):
                                gap_ms = gap['gap_ms']
                                prev = gap['prev']
                                curr = gap['curr']
                                
                                html += f"""
                        <div style="background: white; border-radius: 5px; padding: 15px; margin: 10px 0;">
                            <div style="font-weight: bold; color: #d63031; font-size: 1.2em; margin-bottom: 10px;">
                                间隔 #{j}: {gap_ms}ms
                            </div>
                            <div style="background: #f8f9fa; padding: 10px; margin: 5px 0; border-left: 3px solid #95a5a6;">
                                <strong>前一条:</strong> {prev['timestamp_str']}<br>
                                <code>{prev['class']}</code><br>
                                <textarea readonly style="width:100%;height:60px;resize:vertical;font-size:0.85em;background:#f8f9fa;border:none;color:#666;">{prev['content']}</textarea>
                            </div>
                            <div style="background: #fee; padding: 10px; margin: 5px 0; border-left: 3px solid #e74c3c;">
                                <strong>后一条:</strong> {curr['timestamp_str']}<br>
                                <code>{curr['class']}</code><br>
                                <textarea readonly style="width:100%;height:60px;resize:vertical;font-size:0.85em;background:#fee;border:none;color:#666;">{curr['content']}</textarea>
                            </div>
                            <div style="background: #e8f5e9; padding: 10px; margin-top: 10px; border-radius: 3px;">
                                <strong>分析:</strong> 在 <code>{prev['class']}</code> 和 <code>{curr['class']}</code> 之间耗时 {gap_ms}ms，
                                可能是数据库查询、远程调用或复杂计算导致。
                            </div>
                        </div>
"""
                            html += """
                    </div>
"""

        html += """
                </div>
"""
    
    html += """
        </div>
        
        <div class="footer">
            <p>报告生成时间: """ + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + """</p>
            <p>日志巡检工具 v2.0 | 支持中文分类和智能建议</p>
        </div>
    </div>
</body>
</html>
"""
    
    # 写入文件
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"Report generated: {output_file}")

if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='生成日志分析HTML报告')
    parser.add_argument('digest', help='digest.json 文件路径')
    parser.add_argument('output', help='输出HTML文件路径')
    parser.add_argument('--hospital', default='未知医院', help='医院名称')
    parser.add_argument('--service', default='未知服务', help='服务名称')
    parser.add_argument('--log-file', help='原始日志文件路径（用于时间间隔分析）')
    
    args = parser.parse_args()
    
    generate_html_report_v2(
        args.digest,
        args.output,
        args.hospital,
        args.service,
        '',  # time_range 参数已废弃，从 digest 中读取
        args.log_file
    )
